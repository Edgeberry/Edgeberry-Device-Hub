export default function Settings(props:{user:any}){ return <div>Settings</div>; }
