export default function Register(props:{user:any,onLogin:()=>void}){ return <div>Register</div>; }
