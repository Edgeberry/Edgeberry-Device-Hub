export default function Login(props:{user:any,onLogin:()=>void}){ return <div>Login</div>; }
