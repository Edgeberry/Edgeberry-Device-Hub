export default function Logout(props:{user:any,onLogout:()=>void}){ return <div>Logged out</div>; }
