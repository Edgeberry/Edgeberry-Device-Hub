export default function Admin(props:{user:any}){ return <div>Admin</div>; }
